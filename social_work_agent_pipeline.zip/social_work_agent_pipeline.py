import os
import json
import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field
from openai import AsyncOpenAI

# ==========================================
# 1. 初始化客户端与状态定义
# ==========================================

# 请在此处替换为您实际使用的 API Key 和 Base URL（例如 DeepSeek、OpenAI 等）
client = AsyncOpenAI(
    api_key=os.environ.get("OPENAI_API_KEY", "your-api-key-here"),
    base_url=os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")
)
MODEL_NAME = "gpt-4o"  # 或使用其它支持结构化输出的模型（如 deepseek-chat）

# 定义个案流水线流转的全局状态（State）
class CaseState(BaseModel):
    raw_input: str = Field(..., description="原始走访或电访记录文本")
    deidentified_text: str = ""
    extracted_entities: dict = {}
    risk_assessment: dict = {}
    matched_policies: List[str] = []
    intervention_plan: str = ""
    review_approved: bool = False
    review_comments: str = ""
    final_report: str = ""

# ==========================================
# 2. 定义各个 Agent 的结构化输出 Schema
# ==========================================

class ExtractionSchema(BaseModel):
    deidentified_text: str = Field(..., description="脱敏后的文本。所有真实姓名替换为‘服务对象X’、‘家属Y’，具体地址脱敏到区县，电话身份证等完全隐去。")
    family_structure: str = Field(..., description="家庭结构描述（如：核心家庭、单亲家庭、独居老人等）")
    core_demands: List[str] = Field(..., description="服务对象表达的核心诉求列表")
    key_events: List[str] = Field(..., description="近期发生的重大变故或关键事件")

class RiskAssessmentSchema(BaseModel):
    economic_risk: str = Field(..., description="经济风险评估及多步推导理由")
    psychological_risk: str = Field(..., description="心理/精神健康风险评估及推导理由")
    safety_risk: str = Field(..., description="人身安全/照顾疏忽风险评估及推导理由")
    risk_level: str = Field(..., description="最终确定的风险等级：高风险/中风险/低风险")
    theoretical_basis: str = Field(..., description="推导所依据的社会工作理论（如：生态系统理论、增能理论、优势视角等）")

class PlanSchema(BaseModel):
    matched_policy_names: List[str] = Field(..., description="从知识库中精准匹配到的救助或帮扶政策名称")
    short_term_goals: str = Field(..., description="近期（1-3个月）危机干预或帮扶目标")
    long_term_goals: str = Field(..., description="远期（半年以上）赋能与社会支持网络构建目标")
    action_steps: List[str] = Field(..., description="具体具体的社工行动步骤（如：链接低保、心理疏导、安排志愿者走访等）")

class ReviewSchema(BaseModel):
    approved: bool = Field(..., description="是否通过合规与伦理审查")
    ethical_risks: Optional[str] = Field(None, description="若有，指出违反社工伦理（如自决、隐私、知情同意）或法规的风险点")
    modification_suggestions: Optional[str] = Field(None, description="修改意见或进一步核实信息的建议")

# ==========================================
# 3. 核心 Agent 节点函数实现
# ==========================================

async def agent_privacy_and_extraction(state: CaseState) -> CaseState:
    """Agent 1: 隐私脱敏与实体提取"""
    print("[Agent 1] 正在进行隐私脱敏与关键信息结构化提取...")
    
    system_prompt = (
        "你是一名资深的社会工作档案管理专家。你需要对输入的原始走访记录进行两件事：\n"
        "1. 严格的隐私脱敏：将人名、精确地址、电话等敏感信息抹去或用代称替换，确保无法反向识别。\n"
        "2. 结构化提取：分析服务对象的家庭结构、核心诉求及近期重大变故。"
    )
    
    response = await client.beta.chat.completions.parse(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": state.raw_input}
        ],
        response_format=ExtractionSchema
    )
    
    result = response.choices[0].message.parsed
    state.deidentified_text = result.deidentified_text
    state.extracted_entities = {
        "family_structure": result.family_structure,
        "core_demands": result.core_demands,
        "key_events": result.key_events
    }
    return state


async def agent_risk_assessment(state: CaseState) -> CaseState:
    """Agent 2: 长链推理风险评估"""
    print("[Agent 2] 正在运用社工理论进行长链推理风险评估...")
    
    context = f"脱敏案例背景：{state.deidentified_text}\n结构化特征：{json.dumps(state.extracted_entities, ensure_ascii=False)}"
    system_prompt = (
        "你是一名精通社会工作理论的督导专家。你需要运用‘生态系统理论’或‘优势视角’，"
        "对服务对象的经济、心理、安全三个维度进行深度的长链条逻辑推演。不仅要给出结论，"
        "必须写明推导理由（例如：由于身体残疾导致丧失劳动能力 -> 进而引发家庭经济断缴 -> 导致情绪焦虑及社会孤立）。"
    )
    
    response = await client.beta.chat.completions.parse(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context}
        ],
        response_format=RiskAssessmentSchema
    )
    
    result = response.choices[0].message.parsed
    state.risk_assessment = result.model_dump()
    return state


async def agent_policy_and_planning(state: CaseState) -> CaseState:
    """Agent 3: 政策匹配与干预规划 (模拟 RAG 挂载本地民政政策库)"""
    print("[Agent 3] 正在检索政策库并制定定制化服务计划...")
    
    # 模拟本地极其庞杂的民政与社保政策知识库
    mock_policy_database = (
        "1. 【临时救助政策】：针对突发重大疾病、火灾等导致家庭基本生活陷入困境的，可申请一次性临时救助，额度3000-10000元不等。\n"
        "2. 【最低生活保障（低保）】：共同生活的家庭成员人均收入低于当地低保标准，且家庭财产符合规定的，可申请按月发放低保金。\n"
        "3. 【残疾人两项补贴】：持有残疾人证的困难残疾人可申请生活补贴；重度残疾人（一二级）可申请护理补贴。\n"
        "4. 【高龄独居老人关爱服务】：针对80岁以上独居或失能老人，社区提供每周不少于1次的居家探访及免费适老化改造评估。"
    )
    
    context = (
        f"服务对象特征：{json.dumps(state.extracted_entities, ensure_ascii=False)}\n"
        f"风险评估结果：{json.dumps(state.risk_assessment, ensure_ascii=False)}\n"
        f"本地参考政策库：\n{mock_policy_database}"
    )
    
    system_prompt = (
        "你是一名熟稔地方民政救助政策的落地执行社工。你需要比对服务对象的实际困难与政策库条文，"
        "筛选出最契合的帮扶政策，并制定出包含短期危机干预与长期增能赋能的完整干预计划（Action Steps）。"
    )
    
    response = await client.beta.chat.completions.parse(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context}
        ],
        response_format=PlanSchema
    )
    
    result = response.choices[0].message.parsed
    state.matched_policies = result.matched_policy_names
    state.intervention_plan = (
        f"【匹配政策】：{', '.join(result.matched_policy_names)}\n"
        f"【近期目标】：{result.short_term_goals}\n"
        f"【远期目标】：{result.long_term_goals}\n"
        f"【具体行动步骤】:\n" + "\n".join([f"{i+1}. {step}" for i, step in enumerate(result.action_steps)])
    )
    return state


async def agent_ethical_review(state: CaseState) -> CaseState:
    """Agent 4: 伦理与合规审查 (闭环验证)"""
    print("[Agent 4] 正在进行社会工作专业伦理与合规审查...")
    
    context = (
        f"脱敏文本：{state.deidentified_text}\n"
        f"风险评估：{json.dumps(state.risk_assessment, ensure_ascii=False)}
"
        f"方案计划：{state.intervention_plan}"
    )
    
    system_prompt = (
        "你谨代表‘社会工作伦理委员会’。你需要审查该干预计划是否侵犯了服务对象的隐私权、是否违背了‘案主自决’原则、"
        "是否可能造成次生伤害、行动步骤是否合规可行。如果完全合规，请将 approved 置为 true。"
    )
    
    response = await client.beta.chat.completions.parse(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context}
        ],
        response_format=ReviewSchema
    )
    
    result = response.choices[0].message.parsed
    state.review_approved = result.approved
    state.review_comments = f"伦理风险点：{result.ethical_risks} | 修改建议：{result.modification_suggestions}"
    return state

# ==========================================
# 4. 工作流编排器 (Workflow Orchestrator)
# ==========================================

async def run_social_work_pipeline(raw_case_log: str):
    # 初始化状态
    state = CaseState(raw_input=raw_case_log)
    
    # 顺序流转 Agent 链条
    state = await agent_privacy_and_extraction(state)
    state = await agent_risk_assessment(state)
    state = await agent_policy_and_planning(state)
    state = await agent_ethical_review(state)
    
    # 组装最终报告输出
    print("\n" + "="*20 + " 最终工作流个案综合评估报告 " + "="*20)
    if state.review_approved:
        print("【审查状态】：🟢 伦理与合规审查已通过")
    else:
        print("【审查状态】：🔴 伦理与合规审查未通过（需人工复核修改）")
        print(f"【审查意见】：{state.review_comments}")
        print("-"*60)
        
    print(f"【脱敏个案简述】:\n{state.deidentified_text}\n")
    print(f"【核心特征】:\n{json.dumps(state.extracted_entities, ensure_ascii=False, indent=2)}\n")
    print("【基于生态系统理论的风险推演】:")
    print(f"  - 风险评级: {state.risk_assessment.get('risk_level')}")
    print(f"  - 理论依据: {state.risk_assessment.get('theoretical_basis')}")
    print(f"  - 经济层面推导: {state.risk_assessment.get('economic_risk')}")
    print(f"  - 心理层面推导: {state.risk_assessment.get('psychological_risk')}")
    print(f"  - 安全层面推导: {state.risk_assessment.get('safety_risk')}\n")
    print(f"【具体干预与政策链接方案】:\n{state.intervention_plan}")
    print("="*60)

# ==========================================
# 5. 测试运行
# ==========================================
if __name__ == "__main__":
    # 模拟一段基层社工口吻、包含大量敏感隐私信息的真实非结构化走访录音转写文本
    test_case_log = (
        "今天下午两点，我去了位于光明街道幸福小区3号楼402室的张大爷家走访。张大爷叫张建国，今年74岁，"
        "他的身份证号是1101051952XXXXXXXX，电话1381111XXXX。老人独自居住，老伴前年癌症去世了，"
        "大儿子张明在隔壁市打工，几乎不回来，也不给生活费。张大爷上个月下楼摔断了腿，现在只能架着双拐，"
        "根本没办法自己买菜做饭。今天看他桌上只有一碗剩稀饭和咸菜。张大爷情绪很低落，一直在哭，"
        "说自己成了废人，还不如随老伴一起去了。他现在靠每个月微薄的农村养老保险生活，医药费花了不少，"
        "现在连下个月吃药的钱都快没有了，老人希望能有政府救济或者有人能帮帮他做饭。"
    )
    
    # 运行异步流水线
    asyncio.run(run_social_work_pipeline(test_case_log))
